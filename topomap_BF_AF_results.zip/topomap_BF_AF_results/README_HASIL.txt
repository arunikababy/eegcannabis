HASIL TOPOMAP BF VS AF
==========================

Isi utama:
1. 01_topomap_all_bands_BF_vs_AF: group mean BF dan AF dengan skala warna bersama pada setiap band.
2. 02_topomap_all_bands_difference_AF_minus_BF: mean paired change; merah meningkat, biru menurun.
3. 03_heatmap_percent_change_all_bands: persentase perubahan setiap band-kanal.
4. Berkas 04–13: topomap terpisah per band untuk publikasi/presentasi.
5. statistics_band_channel_20_tests.csv: Wilcoxon dan FDR untuk 20 kombinasi band-kanal.
6. statistics_band_level_5_tests.csv: ringkasan rata-rata empat sensor dan FDR untuk lima band.
7. analisis_otomatis_BF_vs_AF.txt: narasi otomatis berdasarkan hasil run ini.

Aturan interpretasi:
- Topomap adalah distribusi spectral power pada kulit kepala, bukan source localization.
- Warna di antara empat sensor berasal dari interpolasi.
- Kesimpulan inferensial memakai q FDR, bukan warna topomap saja.
- Unit masih raw-unit^2 sampai unit sinyal input dikonfirmasi.
